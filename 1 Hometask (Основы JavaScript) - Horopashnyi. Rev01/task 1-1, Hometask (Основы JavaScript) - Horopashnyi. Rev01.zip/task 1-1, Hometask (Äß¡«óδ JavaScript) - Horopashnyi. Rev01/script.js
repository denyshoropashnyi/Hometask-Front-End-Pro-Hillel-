'use strict';

let weightInGrams = prompt('Please, enter the necessary weight in grams.', '');

alert('Done.\nAnd now look at your result in the console.');

console.log(weightInGrams + ' g', '=', weightInGrams / 1000 + ' kg', '=', weightInGrams / 100000 + ' c', '=', weightInGrams / 1000000 + ' t');